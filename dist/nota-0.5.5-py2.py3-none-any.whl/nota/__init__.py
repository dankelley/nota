#!/usr/bin/python
from main import nota
if __name__ == "__main__":
    nota()

